# ReactJS

## Roteiro

- [x] o que é reactjs?
- [x] criando projeto
- [x] o que são componentes?
- [x] criando header
- [x] buscando produtos da api
- [x] armazenando no estado
- [x] listando produtos
- [x] pógina anterior/próxima
- [x] configurando navegação
- [x] navegando pro detalhe

## Testanto o App React

1. Clone o repositório `git clone https://github.com/marcus-vinicius-fa/rocketseat-skylab-studies.git`

1. Entre na pasta `cd rocketseat-skylab-studies/skylab/4-reactjs/huntweb`

1. Instale as dependências `npm install`

1. Inicie o aplicação `npm start`

1. Acesse [localhost:3000/](http://localhost:3000/)
