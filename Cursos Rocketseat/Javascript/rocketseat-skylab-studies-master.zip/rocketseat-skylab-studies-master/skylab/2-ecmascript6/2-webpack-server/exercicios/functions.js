export const idade = 25;

export default class Usuario {
	static info(string = 'Olá!') {
		console.log(string)
	}
}
