// export default - apenas 1 por arquivo

export default function soma(a, b) {
    return a + b
}
