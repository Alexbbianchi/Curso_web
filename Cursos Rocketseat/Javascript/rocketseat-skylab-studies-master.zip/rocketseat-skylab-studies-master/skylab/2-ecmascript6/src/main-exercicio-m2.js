import ClasseUsuario, { idade as IdadeUsuario } from '../2-webpack-server/exercicios/functions'
// import { idade } from '../2-webpack-server/exercicios/functions'

let usuario = 'Marcus Vinicius'

ClasseUsuario.info(usuario)

console.log(`Idade: ${IdadeUsuario}`)
