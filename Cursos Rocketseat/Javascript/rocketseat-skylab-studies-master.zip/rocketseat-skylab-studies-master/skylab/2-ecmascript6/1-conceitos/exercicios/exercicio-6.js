const usuario = 'Marcus'
const idade = 25

// console.log('O usuário ' + usuario + ' possui ' + idade + ' anos');
console.log(`O usuário ${usuario} possui ${idade} anos`);