const nome = 'Marcus'
const idade = 25

const usuario = {
    nome,
    idade,
    cidade: 'Jacaraú'
}

console.log(usuario)