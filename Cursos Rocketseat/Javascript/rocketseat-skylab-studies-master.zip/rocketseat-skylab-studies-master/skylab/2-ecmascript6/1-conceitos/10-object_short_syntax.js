// Sintaxe curta de objetos

const nome = 'Marcus'
const idade = 25

// const usuario = {
//   nome: nome,
//   idade: idade,
//   empresa: 'Nubank',
// }

const usuario = {
  nome,
  idade,
  empresa: 'Nubank',
}

console.log(usuario)