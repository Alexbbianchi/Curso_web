// Forma de incluir variáveis dentro de strings

const nome = 'Marcus'
const idade = 25

console.log('Meu nome é ' + nome + ', e eu tenho ' + idade + ' anos')

// template litarals
console.log(`Meu nome é ${nome}, e eu tenho ${idade} anos`)