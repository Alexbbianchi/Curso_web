# React Native

## Roteiro

- [ ] o que é react native?
- [ ] criando projeto
- [ ] o que são componentes?
- [ ] configurando navegação
- [ ] estilizando header e statusbar
- [ ] buscando produtos da api
- [ ] entendendo o estado
- [ ] listando produtos
- [ ] estilizando lista de produtos
- [ ] scroll infinito com flatlist
- [ ] detalhe com webview
